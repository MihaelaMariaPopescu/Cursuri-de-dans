window.onload=function(){

    var box=document.createElement("div");
    box.className="box";
    box.innerText="0722513239";

    document.body.appendChild(box);






    var f=document.createElement("footer");
    f.className="footer";
    f.innerHTML="Designed by DominoDance 2022";

    document.body.appendChild(f);


}